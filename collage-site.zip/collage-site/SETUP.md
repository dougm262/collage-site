# Collage site: one-time setup

About 20 minutes, once. After this you add collages from **yoursite/admin**, with no code.

## What's in this folder

- `index.html` is the gallery page.
- `data/collages.json` holds your collages (the admin page edits this for you).
- `data/settings.json` holds the page text: headline, welcome, About, email.
- `admin/` is the admin page where you upload photos.
- `images/uploads/` is where uploaded photos are saved.

## 1. Put the files on GitHub (free)

1. Sign in at github.com, or create a free account.
2. Click **+** (top right) and choose **New repository**. Name it `collage-site`. Leave the other settings alone and click **Create repository**.
3. On the next page click **uploading an existing file**. Drag in everything from this unzipped folder (`index.html`, `SETUP.md`, and the `admin`, `data`, `images` folders), then click **Commit changes**.

## 2. Make one edit

In your new repository on GitHub, open `admin/config.yml` and click the pencil icon. Change `YOUR-GITHUB-USERNAME` to your GitHub username, then click **Commit changes**.

## 3. Connect it to Netlify

1. In Netlify, choose **Add new site → Import an existing project → GitHub**, then pick `collage-site`.
2. Leave the build settings blank (there's no build step) and click **Deploy**.
3. Netlify gives the site an address like `something.netlify.app`. You can rename it under Site configuration.

## 4. Let the admin page sign you in with GitHub

1. On GitHub, go to **Settings → Developer settings → OAuth Apps → New OAuth App**.
   - Application name: `Collage site admin`
   - Homepage URL: your Netlify address, e.g. `https://dougs-collages.netlify.app`
   - Authorization callback URL: `https://api.netlify.com/auth/done`
   - Click **Register application**, then **Generate a new client secret**. Keep this page open.
2. In Netlify, open your site's configuration and find **OAuth** (under Access & security). Choose **Install provider → GitHub** and paste the Client ID and Client Secret.

## 5. Add your collages

1. Go to `https://your-site.netlify.app/admin` and click **Login with GitHub**.
2. **Collages**: click **Add Collage**, upload the photo, fill in title, year, materials and note, then click **Publish**. New pieces go to the top.
3. Delete the six "Placeholder" entries once your real pieces are in.
4. **Page text & About**: edit the headline, welcome text, About and contact email. You can also add a photo of yourself or your work table here.

Each time you publish, Netlify updates the live site in about a minute.

## Tips

- Photograph collages in even daylight, straight on, with no glare. About 2000 px on the long side is plenty.
- If you fill in **Series** on some pieces, filter buttons for each series appear on the gallery automatically.
- A custom domain (like dougcollages.com) can be added later in Netlify under Domain management.
